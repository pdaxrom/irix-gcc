/* 
 * (c) Copyright 1993 Silicon Graphics, INC. 
 * ALL RIGHTS RESERVED 
*/ 
/*   $RCSfile: ColorCP.h,v $ $Revision: 1.8 $ $Date: 1994/10/24 19:17:57 $ */
#ifndef _SgColorChooserP_h
#define _SgColorChooserP_h

#include <Sgm/ColorHexagon.h>
#include <Sgm/GLColorSliderGadgetC.h>
#include <Sgm/CommonColorCP.h>

#endif /* _SgColorChooserP_h */
/* DON'T ADD ANYTHING AFTER THIS #endif */
