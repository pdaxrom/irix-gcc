#ifndef _VK_SO_APP_H
#define _VK_SO_APP_H

#include <Vk/VkApp.h>

class VkSoApp  : public VkApp { 

  public:

    VkSoApp ( char           *appClassName,
            int              *arg_c, 
            char            **arg_v,
            XrmOptionDescRec *optionList       = NULL,
            int               sizeOfOptionList = 0);
            
    ~VkSoApp();

    void run();

  protected:

  private:
};

#endif

