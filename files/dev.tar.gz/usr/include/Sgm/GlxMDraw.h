#ifndef __GLX_MOTIF
#define __GLX_MOTIF 1
#endif
#include <Sgm/GlxDraw.h>
