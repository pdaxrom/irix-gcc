/*ident	"@(#)ctrans:incl-master/proto-headers/sysent.h	1.2" */

#ifndef __SYSENT_H
#define __SYSENT_H

#include <osfcn.h>

#endif
