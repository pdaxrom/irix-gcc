#ifndef VKFORMAT_H
#define VKFORMAT_H

const char * VkFormat(const char* fmt, ...);


#endif

