#ifndef VKSETUPLOCATEHIGHLIGHT
#define VKSETUPLOCATEHIGHLIGHT

void VkSetupLocateHighlight();

#endif

