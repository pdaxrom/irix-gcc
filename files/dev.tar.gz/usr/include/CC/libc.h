/*ident	"@(#)ctrans:incl-master/proto-headers/libc.h	1.7" */
#ifndef __LIBC_H
#define __LIBC_H
#include <osfcn.h>
#endif
