////////////////////////////////////////////////////////////////////////////////
///////   Copyright 1992, Silicon Graphics, Inc.  All Rights Reserved.   ///////
//                                                                            //
// This is UNPUBLISHED PROPRIETARY SOURCE CODE of Silicon Graphics, Inc.;     //
// the contents of this file may not be disclosed to third parties, copied    //
// or duplicated in any form, in whole or in part, without the prior written  //
// permission of Silicon Graphics, Inc.                                       //
//                                                                            //
// RESTRICTED RIGHTS LEGEND:                                                  //
// Use,duplication or disclosure by the Government is subject to restrictions //
// as set forth in subdivision (c)(1)(ii) of the Rights in Technical Data     //
// and Computer Software clause at DFARS 252.227-7013, and/or in similar or   //
// successor clauses in the FAR, DOD or NASA FAR Supplement. Unpublished -    //
// rights reserved under the Copyright Laws of the United States.             //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
#ifndef VKFUNCTION_H
#define VKFUNCTION_H

#include <X11/Xlib.h>


// This is a more flexible version of the traditional Unix "assert" macro.
// It is intended for those cases where hard assertions cause trouble.  If
// the assertion fails, then:
//
//	* If the environment variable VK_FORCE_ABORT is set, then it
//	  just calls __assert, resulting in the normal message and core dump.
//
//	* Otherwise, it Gives a warning on stderr if the assertion fails.

#ifdef NDEBUG
#  undef VkAssert
#  define VkAssert(EX) ((void)0)

#else
   extern void _VkAssert (const char*, const char*, int, int=0);
#  ifdef __ANSI_CPP__
#     define VkAssert(EX) \
	((EX)?((void)0):_VkAssert( # EX , __FILE__, __LINE__))
#  else
#     define VkAssert(EX) \
	((EX)?((void)0):_VkAssert("EX", __FILE__, __LINE__))
#  endif

#endif /* NDEBUG */


// Prints a description of the event to stderr.  Right now, not a lot is
// printed, but that can be expanded if the need arises.  The second
// argument is a provision for future enum control over just what is printed.
//
// Note that this is intended to help debug.  Just what it prints may
// change in the future.
//
   extern void VkPrintEvent (XEvent *, int=0);



#endif /* VKFUNCTION_H */
