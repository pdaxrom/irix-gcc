/* 
 * (c) Copyright 1993 Silicon Graphics, INC. 
 * ALL RIGHTS RESERVED 
*/ 
/*   $RCSfile: OglColorCP.h,v $ $Revision: 1.2 $ $Date: 1994/10/24 19:18:35 $ */
#ifndef _OglColorCP_h
#define _OglColorCP_h

#include <Sgm/OglColorHexagon.h>
#include <Sgm/OglColorSliderGadgetC.h>
#include <Sgm/CommonColorCP.h>

#endif /* _OglColorCP_h */
/* DON'T ADD ANYTHING AFTER THIS #endif */
